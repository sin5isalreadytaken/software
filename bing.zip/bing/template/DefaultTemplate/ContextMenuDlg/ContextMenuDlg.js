//ban drag of <img> and select of header
$(document).ready(
function () {
    $('img').bind('dragstart', function(){return false;});
    $('#header').bind('selectstart', function(){return false;});
	
	$('.MenuItem').bind('mouseover',function(){$(this).siblings().removeClass('Hovered');$(this).addClass('Hovered');})
	.bind('mouseout',function(){$(this).removeClass('Hovered');})
	.bind('click',function(){MenuItem_onclick(this);});
}
);

function MenuItem_onclick(obj)
{
	window.external.HideWin();
	switch (obj.id)
	{
		case "paste-search-dict":
		window.external.PasteSearchDict();
		break;
		
		case "paste-search-bing":
		window.external.PasteSearchBing();
		break;
		
		case "paste-search-minimode-dict":
		window.external.PasteSearchMiniModeDict();
		break;
		
		case "paste-search-minimode-bing":
		window.external.PasteSearchMiniModeBing();
		break;
		
		case "cut":
		window.external.Cut();
		break;
		
		case "copy":
		window.external.Copy();
		break;
		
		case "paste":
		window.external.Paste();
		break;
		
		case "delete":
		window.external.Delete();
		break;
		
		case "delete-all":
		window.external.DeleteAll();
		break;
		
		case "select-all":
		window.external.SelectAll();
		break;
		
		case "open-exapp":
		window.external.OpenExApp(curAppId);
		break;
		
		case "pin-to-desktop":
		window.external.PinToDesktop(curAppId);
		break;
		
		case "pin-to-taskbar":
		window.external.PinToTaskBar(curAppId);
		break;
		
		case "open-promote-app-url":
		window.external.OpenPromoteAppUrl(CurPromoteAppId);
		break;
		
		case "show-promote-app-qrcode":
		window.external.ShowPromoteAppQRCode(CurPromoteAppId);
		break;
		
		case "get-selected-search-dict":
		window.external.GetSelectedSearchDict();
		window.external.GetSelectedSearchDict();
		break;
		
		case "show-main-window":
		window.external.ShowMainWindow();
		break;
		
		case "show-settings":
		window.external.ShowSettings();
		break;
		
		case "open-newwordlist":
		window.external.OpenNewWordList();
		break;
		
		case "hover-translate-toggle":
		window.external.HoverTranslateToggle();
		break;
		
		case "select-translate-toggle":
		window.external.SelectTranslateToggle();
		break;
		
		case "minimode-hover-translate-toggle":
		window.external.HoverTranslateToggle();
		break;
		
		case "minimode-select-translate-toggle":
		window.external.SelectTranslateToggle();
		break;
		
		case "quit":
		window.external.Quit();
		break;
		
		default:
		break;
	}
	
}

var curPanel='input-menu';
function CurrentPanel()
{
	return curPanel;
}
function switchToPanel(panelId)
{
	$('#panels #'+panelId).siblings().removeClass('selected');
	$('#panels #'+panelId).addClass('selected');
	curPanel=panelId;
	
	$('#panels #'+panelId+' .MenuItem').removeClass('Hovered');
}
function changeMenuItemStatus(id,status)
{
	if (status=="enable")
	{
		$("div#"+id+" div.MenuIconImg").addClass("enabled");
	}
	else if (status=="disable")
	{
		$("div#"+id+" div.MenuIconImg").removeClass("enabled");
	}
}

var curAppId='8';
function setAppId(appId)
{
	curAppId = appId;
}

var CurPromoteAppId='';
function setCurrentPromoteAppId(id)
{
	CurPromoteAppId = id;
}

function Enter_onclick()
{
	var $Items = $('#panels .selected .MenuItems .MenuItem');
	var $hoveredItem = $Items.siblings('.Hovered');
	$hoveredItem.click();
	window.external.HideWin();
}

function OnKeyDown_UpDown(para)
{
	OnKeyDown_UpDown_CheckMenu(para);
}

function OnKeyDown_UpDown_CheckMenu(para)
{
	var $Items = $('#panels .selected .MenuItems .MenuItem');
	var $hoveredItem = $Items.siblings('.Hovered');
	var $theItem;
	
	if ($hoveredItem.length==0)
	{
		if (para=='up')
		{
			$theItem=$Items.last();
		}
		else if (para=='down')
		{
			$theItem=$Items.first();
		}	
	}
	else if ($hoveredItem.length>=1)
	{
		if (para=='up')
		{
			$theItem = (function()
			{
				var item=$hoveredItem.prev();
				while (!item.hasClass('MenuItem') && item.prev().length>0)
				{
					item=item.prev();
				}
				return item;
			})();
			
			if ($theItem.length==0)
			{
				$theItem=$Items.last();
			}
		}
		else if (para=='down')
		{
			$theItem = (function()
			{
				var item=$hoveredItem.next();
				while (!item.hasClass('MenuItem') && item.next().length>0)
				{
					item=item.next();
				}
				return item;
			})();
			
			if ($theItem.length==0)
			{
				$theItem=$Items.first();
			}
		}	
	}
	$Items.siblings('.Hovered').removeClass('Hovered');
	$theItem.addClass('Hovered');
}



/********skin********/
var CurSkinModel = "DefaultModel";
var CurSkinColor = "Blue.css";
var CurSkinImage = "";
function GetCurrentSkinModel()
{
    return CurSkinModel;
}

function GetCurrentSkinColor()
{
    return CurSkinColor;
}

function GetCurrentSkinImage()
{
    return CurSkinImage;
}

function UpdateSkinForPage(model, color, image)
{
    CurSkinModel = model;
    CurSkinColor = color;
    CurSkinImage = image;
    $("link#_NewSkinModel").attr("href", "").attr("href", "../../../skin/Model/" + model + "/ContextMenuDlg/ContextMenuDlg.css");
}
