﻿//ban drag of img
$(document).ready(
function () {
    $('img').bind('dragstart', function () { return false; });
}
);


//to detect whether a function exists
function funExists(funName)
{ 
	try
	{  
		if (typeof eval(funName)=="undefined"){return false;} 
		if (typeof eval(funName)=="function"){return true;}
	}
	catch(e)
	{
		return false;
	} 
} 

//----------------------------------------------------------------------
//detect onmouseout ,onmouseover,and change dlg's transparency respectively.
var bAlreadyOver = false;
function detectOnMouseOutOnMouseOver(evt) {
    if (document.body.attachEvent)//ie5+ and other
    {
        document.body.attachEvent("onmouseover", function () { document_onmouseover(evt); });
        document.body.attachEvent("onmouseout", function () { document_onmouseout(evt); });
    }
    else if (document.body.addEventListener) //firefox only
    {
        document.body.addEventListener("onmouseover", function () { document_onmouseover(); }, false);
        document.body.addEventListener("onmouseout", function () { document_onmouseout(); }, false);
    }

    function document_onmouseover(evt) {
        if (!bAlreadyOver) {
            window.external.OnMouseOver();
            bAlreadyOver = true;
        }
    }

    function document_onmouseout(evt)
    {
        var evt = evt ? evt : window.event;
        var x = evt.clientX;
        var y = evt.clientY;
        var w = document.body.clientWidth;
        var h = document.body.clientHeight;
        if (x >= 0 && x < w && y >= 0 && y < h) //eliminate the false onblur event
        {
            //do nothing,just return.
            return false;
        }
        window.external.OnMouseOut();
        bAlreadyOver = false;
    }
}



/******************Query History********************/

function getQueryHistPageContains(QueryIndex)
{
	window.external.GetQueryRecPageContains(QueryIndex);
}

function insertQueryHistItem(itemStr)
{
	$('#AutoSuggestion').hide();
	$('#QueryHist').show();
	
	$('#QueryHistItems').html('').html(itemStr);
}

function updateQueryHistPage(currentPageIndex,totalPageIndex)
{
	//use this information to update the BtnQueryHistBack,QueryHistCurrentPos,BtnQueryHistForward
	if (currentPageIndex<=1)
	{
		currentPageIndex=1;
		$("#BtnQueryHistBack").attr("class","BtnQueryHistBack_D");
	}
	else 
	{
		$("#BtnQueryHistBack").attr("class","normal_ba");
	}
	
	if (currentPageIndex>=totalPageIndex)
	{
		currentPageIndex=totalPageIndex;
		$("#BtnQueryHistForward").attr("class","BtnQueryHistForward_D");
	}
	else
	{
	    $("#BtnQueryHistForward").attr("class", "normal_ba");
	}
	
	$("#QueryHistCurrentPos").html(currentPageIndex.toString()+"/"+totalPageIndex.toString());
}

function QueryHistContent_onclick(obj) 
{
	window.external.AddToLog('ViewMiniModeHistoryItem');
	//obj is div.QueryHistItem
	var content=obj;
	var word="";
	for (var j=0;j<content.childNodes.length;j++)
	{
		if (content.childNodes[j].className=="QueryHistWord")
		{
		    word = (content.childNodes[j].innerHTML).ToHtmlDecode();
			break;
		}
	}
	window.external.SearchMiniMode(word);
}

function BtnQueryHistDelete_onclick(obj) 
{
	window.external.AddToLog('DeleteMiniModeHistoryItem');
	//delete the word
	//1.find the index represent this query
	//obj is img.BtnQueryHistDelete
	var nodes=obj.parentNode.parentNode.childNodes;
	var index=-1;
	for (var i=0;i<nodes.length;i++)
	{
		if (nodes[i].className=="QueryHistIndex")
		{	
			index=parseInt(nodes[i].innerHTML);
			break;
		}
	}
	
	if (isNaN(index)||index<0)
	{//this is impossible to happen
		return;
	}
	//2.call window.external to delete the query
    window.external.DeleteQueryRecItem(index);
	//reload the items in the query history list
	getQueryHistPageContains(index);
}

function BtnQueryHistBack_onclick()
{
	if ($("#BtnQueryHistBack").attr("className")=='BtnQueryHistBack_D')
	{
		return;
	}
	//find the first item in this page,and find out its index
	var index = getQHCurrentPageFirstItemIndex();
	//then
	if (isNaN(index)||index<0)
	{//this is impossible to happen
		return;
	}
	getQueryHistPageContains(index-10);
}

function BtnQueryHistForward_onclick()
{
	if ($("#BtnQueryHistForward").attr("className")=='BtnQueryHistForward_D')
	{
		return;
	}
	//find the first item in this page,and find out its index
	var index=getQHCurrentPageFirstItemIndex();
	//then
	if (isNaN(index)||index<0)
	{//this is impossible to happen
		return;
	}
	getQueryHistPageContains(index+10);
}

function getQHCurrentPageFirstItemIndex()
{
	var index=-1;
	
	var nodes=document.getElementById("QueryHistItems").childNodes;
	for (var i=0;i<nodes.length;i++)
	{
		if (nodes[i].className=="QueryHistItem")
		{
			var item=nodes[i];
			
			for (var j=0;j<item.childNodes.length;j++)
			{
				if (item.childNodes[j].className=="QueryHistIndex")
				{
					index= parseInt(item.childNodes[j].innerHTML.toString());
					break;
				}
			}
			break;
		}
	}
	return index;
}

function BtnQueryHistClear_onclick() 
{
    window.external.AddToLog('ClearMiniModeSearchHistory');
	//clear all the items
    window.external.ClearQueryNavList();
    window.external.ClearQueryRecList();
	//reload the items in the query history list
	getQueryHistPageContains(0);
}

function isQueryHistShown()
{
	return $('#QueryHist').is(':visible');
}	

function isAutoSuggestionShown()
{
	return $('#AutoSuggestion').is(':visible');
}

/******************Auto Suggestion********************/

function InsertAutoSuggestionItem(items)
{
	$('#QueryHist').hide();
	$('#AutoSuggestion').show();
	$('#AutoSuggestion').html('').html(items);
}

function ASItem_onclick(obj) 
{
    window.external.AddToLog('ViewMiniModeASItem');
	var nodes=obj.childNodes;
	var word="";
	for (var i=0;i<nodes.length;i++)
	{
		if (nodes[i].className=="ASHighlight")
		{
			word+=nodes[i].innerHTML;
		}
		if (nodes[i].className=="ASWord")
		{
			word+=nodes[i].innerHTML;
		}
	}
	word = word.replace(/&nbsp;/g," ");
	window.external.SearchMiniMode(word);
}

function OnKeyDown_UpDown(para)
{
	OnKeyDown_UpDown_CheckAutoSug(para);
	OnKeyDown_UpDown_CheckQueryHist(para);
}

function OnKeyDown_UpDown_CheckAutoSug(para)
{
	var queryHist=document.getElementById('AutoSuggestion');
	if (queryHist==undefined||queryHist.style.display=="none")
	{
	    return;
	}
	else
	{
		if (para=='up') //up
		{
		   AutoSugMenuItemUp();
		}
		else if (para=='down') //down
		{
		   AutoSugMenuItemDown();
		}
	}

}

function AutoSugMenuItemUp()
{
	var autoSuggestion=document.getElementById("AutoSuggestion");
	if (autoSuggestion==null||autoSuggestion.style.display=='none')
	{
		return;
	}
	
	var $Selected=$("#AutoSuggestion .ASItem.selected").first().prev();
	$("#AutoSuggestion .ASItem.selected").removeClass("selected");
	if ($Selected.length<=0)
	{
		$("#AutoSuggestion .ASItem").last().addClass("selected")
	}
	else
	{
		$Selected.addClass("selected");
	}
	
	var value = $("#AutoSuggestion .ASItem.selected div.ASHighlight").html()
	+ $("#AutoSuggestion .ASItem.selected div.ASWord").html();	
	
	value=value.replace(/&nbsp;/g," ");

	window.external.ChangeTextMiniMode(value);
}

function AutoSugMenuItemDown()
{
	var autoSuggestion=document.getElementById("AutoSuggestion");
	if (autoSuggestion==null||autoSuggestion.style.display=='none')
	{
		return;
	}

	var $Selected=$("#AutoSuggestion .ASItem.selected").first().next();
	$("#AutoSuggestion .ASItem.selected").removeClass("selected");
	if ($Selected.length<=0)
	{
		$("#AutoSuggestion .ASItem").first().addClass("selected")
	}
	else
	{
		$Selected.addClass("selected");
	}
	
	var value=$("#AutoSuggestion .ASItem.selected div.ASHighlight").html()
	+$("#AutoSuggestion .ASItem.selected div.ASWord").html();

	value=value.replace(/&nbsp;/g," ");

	window.external.ChangeTextMiniMode(value);
}

function OnKeyDown_UpDown_CheckQueryHist(para)
{
	var queryHist=document.getElementById('QueryHist');
	if (queryHist==undefined||queryHist.style.display=="none")
	{
	    return;
	}
	else
	{ 
		//highlight the next of query hist item, then try to 
		if ($('.QueryHistItem').length>0)
		{
			var query='';
			if ($('.QueryHistItem.Hovered').length>=1)
			{
				if (para=='down')
				{
					var theItem=$('.QueryHistItem.Hovered').next();
					if (theItem.length==0)
					{
						theItem=$('.QueryHistItem').first();
					}
					$('.QueryHistItem.Hovered').removeClass('Hovered');
					theItem.addClass('Hovered');
					query = (theItem.find('.QueryHistWord').html()).ToHtmlDecode();
				}
				else if (para=='up')
				{
					var theItem=$('.QueryHistItem.Hovered').prev();
					if (theItem.length==0)
					{
						theItem=$('.QueryHistItem').last();
					}
					$('.QueryHistItem.Hovered').removeClass('Hovered');
					theItem.addClass('Hovered');
					query = (theItem.find('.QueryHistWord').html()).ToHtmlDecode();
				}
			}
			else
			{
				if (para=='down')
				{
					var theItem=$('.QueryHistItem').first();
					$('.QueryHistItem.Hovered').removeClass('Hovered');
					theItem.addClass('Hovered');
					query = (theItem.find('.QueryHistWord').html()).ToHtmlDecode();
				}
				else if (para=='up')
				{
					var theItem=$('.QueryHistItem').last();
					$('.QueryHistItem.Hovered').removeClass('Hovered');
					theItem.addClass('Hovered');
					query = (theItem.find('.QueryHistWord').html()).ToHtmlDecode();
				}
			}
		
			value=query.replace(/&nbsp;/g," ");
			
			window.external.ChangeTextMiniMode(value);
		}
	}
}


/********skin********/
var CurSkinModel = "DefaultModel";
var CurSkinColor = "Blue.css";
var CurSkinImage = "";
function GetCurrentSkinModel()
{
    return CurSkinModel;
}

function GetCurrentSkinColor()
{
    return CurSkinColor;
}

function GetCurrentSkinImage()
{
    return CurSkinImage;
}

function UpdateSkinForPage(model, color, image)
{
    CurSkinModel = model;
    CurSkinColor = color;
    CurSkinImage = image;
    $("link#_NewSkinModel").attr("href", "").attr("href", "../../../skin/Model/" + model + "/MiniModeListDlg/MiniModeListDlg.css");
    $("link#_NewSkinColor").attr("href", "").attr("href", "../../../skin/Color/" + color + ".css");
    $("link#_NewSkinImage").attr("href", "").attr("href", "../../../skin/Image/" + image + "/BgImg.css");
}

