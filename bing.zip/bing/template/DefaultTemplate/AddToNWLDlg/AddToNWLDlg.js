﻿//ban drag of <img> and select of header
$(document).ready(
function () {
    $('img').bind('dragstart', function(){return false;});
    $('#header').bind('selectstart', function(){return false;});
}
);


function shouldBanBackspace()
{
    var obj = document.activeElement;//获取当前焦点的对象  

    if (document.activeElement == undefined || document.activeElement.tagName == "IFRAME" || document.activeElement.type == undefined)
	{
		return true;
	}

    var t = obj.type || obj.getAttribute('type');//获取事件源类型       
    //获取作为判断条件的事件类型   
    var vReadOnly = obj.readOnly;  
    var vDisabled = obj.disabled;  
    //处理undefined值情况   
    vReadOnly = (vReadOnly == undefined) ? false : vReadOnly;  
    vDisabled = (vDisabled == undefined) ? true : vDisabled;  
    //当敲Backspace键时，事件源类型为密码或单行、多行文本的，    
    //并且readOnly属性为true或disabled属性为true的，则退格键失效    
    var flag1 = (t == "password" || t == "text" || t == "textarea") && (vDisabled == true);  
    //当敲Backspace键时，事件源类型非密码或单行、多行文本的，则退格键失效      
    var flag2 = (t != "password" && t != "text" && t != "textarea");

    if (flag1 || flag2) 
    {
		return true;
	}
    else 
    {
		return false;
	}
	
}

//to detect whether a function exists
function funExists(funName)
{ 
	try
	{  
		if (typeof eval(funName)=="undefined"){return false;} 
		if (typeof eval(funName)=="function"){return true;}
	}
	catch(e)
	{
		return false;
	} 
} 

function header_mouse_down()
{
	window.external.OnHeaderMouseDown();
}

//------------------------------------------------------------------------------
//BtnClose
function BtnClose_onclick()
{
    window.external.HideWin();
}


function changeWord(value)
{
	var val=value?value:"";
	$("#word-container").val(val);
}

function changePron(value)
{
	var val=value?value:"";
	$("#pron-container").val(val);
}

function changeDef(value)
{
	var val=value?value:"";
	$("#def-container").val(val);
}

function Add_onclick()
{
	if ($("#word-container").val().replace(/(^\s*)|(\s*$)/g,"").length>0 && $("#def-container").val().replace(/(^\s*)|(\s*$)/g,"").length>0)
	{
		window.external.AddNewWord($("#word-container").val(),$("#pron-container").val(),$("#def-container").val());
		window.external.HideWin(); 
	}
	else
	{
		$('#warning').css({'opacity':0,'display':'block'})
		.animate({'opacity':1},500)
		.delay(1000).animate({'opacity':0},500,function(){ $('#warning').css('display','none');} );
		
	}
}


/********skin********/
var CurSkinModel = "DefaultModel";
var CurSkinColor = "Blue.css";
var CurSkinImage = "";
function GetCurrentSkinModel()
{
    return CurSkinModel;
}

function GetCurrentSkinColor()
{
    return CurSkinColor;
}

function GetCurrentSkinImage()
{
    return CurSkinImage;
}

function UpdateSkinForPage(model, color, image)
{
    CurSkinModel = model;
    CurSkinColor = color;
    CurSkinImage = image;
    $("link#_NewSkinModel").attr("href", "").attr("href", "../../../skin/Model/" + model + "/AddToNWLDlg/AddToNWLDlg.css");
    $("link#_NewSkinColor").attr("href", "").attr("href", "../../../skin/Color/" + color + ".css");
    $("link#_NewSkinImage").attr("href", "").attr("href", "../../../skin/Image/" + image + "/BgImg.css");
}
