
//ban drag of <img> and select of header
$(document).ready(
function ()
{
    $('img').bind('dragstart', function(){return false;});
    $('#header').bind('selectstart', function(){return false;});
	
	$('.btn').bind('mouseover',function(){$(this).siblings().removeClass('Hovered');$(this).addClass('Hovered');})
	.bind('mouseout',function(){$(this).removeClass('Hovered');})
	.bind('click',function(){btn_onclick(this);});
}
);


function btn_onclick(obj)
{
	window.external.BtnOnClick(obj.id);
}

//to detect whether a function exists
function funExists(funName)
{ 
	try
	{  
		if (typeof eval(funName)=="undefined"){return false;} 
		if (typeof eval(funName)=="function"){return true;}
	}
	catch(e)
	{
		return false;
	} 
} 

/********skin********/
function UpdateSkinForPage(model, color, image)
{
    CurSkinModel = model;
    CurSkinColor = color;
    CurSkinImage = image;
    $("link#_NewSkinModel").attr("href", "").attr("href", "../../../skin/Model/" + model + "/AddToNWLDlg/AddToNWLDlg.css");
    $("link#_NewSkinColor").attr("href", "").attr("href", "../../../skin/Color/" + color + ".css");
}