
function checkInNewWordList()
{
    var obj = document.getElementById("addToNewWordList");
    if (obj == undefined) 
    {
        return;
    }

	var dictBarChildNodes= obj.parentNode.childNodes;//childNodes in dictBar
	var headword="",pron="",def="";

	for (var i=0;i<dictBarChildNodes.length;i++)
	{
		var item=dictBarChildNodes[i];
		if (item.nodeType===1)
		{
			if (item.className.toLowerCase()=="dictbartitle")
			{
			    headword = (item.innerHTML).ToHtmlDecode();
				break;
			}
		}
	}
	
	//the following call will lead to crash when headword containing a single quotation mark :window.external.IsInNewWordList
	if (Number(window.external.IsInNewWordList(headword))==0)
	{
		obj.className="";
		obj.className="addToNewWordList_Pending_N";
		obj.title="添加到生词本";
	}
	else
	{	
		obj.className="";
		obj.className="addToNewWordList_Added_N";
		obj.title="已添加到生词本,点击删除"; 
	}
	
}


function addToNewWordList_onclick(obj)
{
	var dictBarChildNodes= obj.parentNode.childNodes;//childNodes in dictBar
	var headword="",pron="",def="";
	for (var i=0;i<dictBarChildNodes.length;i++)
	{
		var item=dictBarChildNodes[i];
		if (item.nodeType===1)
		{
			if (item.className.toLowerCase()=="dictbartitle")
			{
			    headword = (item.innerHTML).ToHtmlDecode();
			}
			if (item.className.toLowerCase()=="dictbarprons")
			{
				for (var j=0;j<item.childNodes.length;j++)
				{
					var dictBarPron=item.childNodes[j];
			
					if (dictBarPron.nodeType===1 && dictBarPron.className.toLowerCase()=="dictbarpron")
					{
				
						for (var k=0;k<dictBarPron.childNodes.length;k++)
						{
							var dictBarPronValue=dictBarPron.childNodes[k];
							if (dictBarPronValue.className=="dictBarPronValue")
							{
								pron=dictBarPronValue.innerHTML;
								break;
							}
						}
						
					}
				}
			}
		}
	}
	var defGroupChildNodes=obj.parentNode.nextSibling.childNodes;//childNodes in defGroups
	for (var i=0;i<defGroupChildNodes.length;i++)
	{
		var defGroup=defGroupChildNodes[i];
		for (var j=0;j<defGroup.childNodes.length;j++)
		{
			var item3=defGroup.childNodes[j];
			if (item3.nodeType===1)
			{
			    if (item3.className == "defPosArea")
			    {
			        def = def + item3.childNodes[0].innerHTML + " ";
			    }
			    if (item3.className == "defCnt")
			    {
			        def = def + item3.innerHTML.replace(/; /g, "；").replace(/;/g, "；") + "; ";
			    }
			}		
		}		
	}
	if (def == "") { def = "<空>";}
	
	if (obj.title=="添加到生词本")
	{
		
		window.external.AddNewWord(headword,pron,def);

		if (Number(window.external.IsInNewWordList(headword))!=0)
		{
			obj.className="";
			obj.className="addToNewWordList_Added_N";
			obj.title="已添加到生词本,点击删除";
        }
        window.external.AddToLog("AddNewWordInCrossTran");
	}
	else 
	{
		window.external.DeleteNewWord(headword);

		if (Number(window.external.IsInNewWordList(headword))==0)
		{
			obj.className="";
			obj.className="addToNewWordList_Pending_N";
			obj.title="添加到生词本";
		}
	}
}

function checkAutoPron()
{
    if (Number(window.external.IsAutoPronEnabled()) == 1 && $('.dictBarSignature').html().length > 1)
    {
        setTimeout(function () { playAudio_onclick(); }, 0);
    }
}

function playAudio_onclick()
{
	var audioPlayer=document.getElementById("_aplayer");
	if (audioPlayer==undefined || audioPlayer==null)
	{
		var a=document.createElement("div");
		a.style.display="none";
		a.innerHTML="\
<object \
id='_aplayer' \
style='width:0px;height:0px;' \
classid='clsid:d27cdb6e-ae6d-11cf-96b8-444553540000' \
width='0' \
height='0' \
type='application/x-shockwave-flash'>\
<param name='allowScriptAccess' value='sameDomain'/>\
<param name='movie' value='../Common/EhcPlayer.swf'/>\
<param name='quality' value='high'/>\
</object>\
		";
		
		document.body.appendChild(a);
	}

    var url = 'http://media.engkoo.com:8129/en-us/' + $('.dictBarSignature').html() + '.mp3';
    var audioPlayer = document.getElementById("_aplayer");

    try 
	{
        audioPlayer.SetVariable("hash", url);
        audioPlayer.GotoFrame(2); //Stop potentially any playing sounds
        audioPlayer.GotoFrame(1);
    } 
	catch (e) 
	{
	    if (audioPlayer.Settings)
	    {
	        audioPlayer.Settings.PlayCount = 1; //Call Settings.PlayCount especially to draw an exception if this is not present
	        audioPlayer.URL = url;
	    }
    }
	
	window.external.AddToLog("AudioInSelectTranslate");
}

function AlignWord(obj)
{
	var elements=document.getElementsByName(obj.name);
	for (var i=0;i<elements.length;i++)
	{
		elements[i].className="aligned";
	}
}

function UnalignWord(obj)
{
	var elements=document.getElementsByName(obj.name);
	for (var i=0;i<elements.length;i++)
	{
		elements[i].className="unaligned";
	}
}


function SearchWord(obj)
{
    if (parent.bTranslateSearch)
    {
        window.external.SearchOnline(obj.innerHTML);
    }
}

/********skin********/
function UpdateSkinForPage(model, color, image)
{
    CurSkinModel = model;
    CurSkinColor = color;
    CurSkinImage = image;
    $("link#_NewSkinModel").attr("href", "").attr("href", "../../../skin/Model/" + model + "/SelectTranslateDlg/OnlineResult.css");
    $("link#_NewSkinColor").attr("href", "").attr("href", "../../../skin/Color/" + color + ".css");
}