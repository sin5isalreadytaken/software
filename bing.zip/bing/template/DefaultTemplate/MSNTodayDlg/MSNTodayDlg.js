//ban drag of <img> and select of header
$(document).ready(
function () 
{
    $('img').bind('dragstart', function(){return false;});
    $('#header').bind('selectstart', function(){return false;});
}
);


//获取元素的纵坐标 
function getTop(e)
{ 
	var offset = e.offsetTop; 
	if (e.offsetParent != null) offset += getTop(e.offsetParent); 
	return offset; 
} 
//获取元素的横坐标 
function getLeft(e)
{ 
	var offset = e.offsetLeft; 
	if (e.offsetParent != null) offset += getLeft(e.offsetParent); 
	return offset; 
} 

//获取所有class==n的元素
function getElementsByClassName(n) 
{ 
	var classElements = [], allElements = document.getElementsByTagName('*'); 
	for (var i=0; i< allElements.length; i++ ) 
	{ 
		if (allElements[i].className == n ) 
		{ 
			classElements[classElements.length] = allElements[i]; //某类集合
		} 
	} 
	return classElements; 
}

//内存回收
window.setInterval(
function gc(){if (document.all) CollectGarbage();}, 
60000
); 


function header_mouse_down()
{
	window.external.OnHeaderMouseDown();
}


var bInSettingMenuArea = false;
function Setting_onblur()
{
	if (bInSettingMenuArea) 
	{ 
		$('#setting').focus();
		return false;
	}
    else 
	{ 
        hideSettingMenu();
    }
}

function Setting_onclick()
{
	toggleSettingMenu();
}

function createSettingMenu()
{
	var ItemString = '\
	<div id="SettingMenu"  onmouseenter="bInSettingMenuArea=true;" onmouseleave="bInSettingMenuArea=false;">\
		<div class="SettingMenu_Item" id="SettingMenu_Item1"\
		onmousedown="hideSettingMenu();changeSetting(this);" \
		onmouseover="$(this).siblings().removeClass(\'Hovered\');$(this).addClass(\'Hovered\');"\
		onmouseout="$(this).removeClass(\'Hovered\');"\
		>\
			<div class="SettingMenuIcon">\
				<div class="MenuIconImg enabled"></div>\
			</div>\
			<div class="SettingMenuTxt">自动弹出</div>\
		</div>\
		<div class="SettingMenu_Segment">\
        	<div class="SettingMenuTxt"></div>\
        </div>\
		<div class="SettingMenu_Item" id="SettingMenu_Item2"\
		onmousedown="hideSettingMenu();changeSetting(this);"\
		onmouseover="$(this).siblings().removeClass(\'Hovered\');$(this).addClass(\'Hovered\');"\
		onmouseout="$(this).removeClass(\'Hovered\');"\
		>\
			<div class="SettingMenuIcon">\
				<div class="MenuIconImg"></div>\
			</div>\
			<div class="SettingMenuTxt">不再显示</div>\
		</div>\
	</div>\
    ';
    	
	var menu=document.getElementById("SettingMenu");
	if (menu==undefined || menu==null)
	{
		var a=document.createElement("div");
		a.innerHTML=ItemString;
		document.body.appendChild(a);
	}
	menu=document.getElementById("SettingMenu");
	menu.style.display="none";
	return;
}

function changeSettingMenuPosition()
{
	var BtnSetting=document.getElementById("BtnSetting");
	var x=getLeft(BtnSetting);
	var y=getTop(BtnSetting);
	var x2=x;
	var y2=y+25;

	var menu=document.getElementById("SettingMenu");
	menu.style.top=y2+'px';
	menu.style.left=x2+'px';
	return;
}

function updateSettingMenuStatus()
{
	var status = window.external.GetMsnTodayStatus();
	var menuItemId = 'SettingMenu_Item' + status;
	var obj = document.getElementById(menuItemId);
	
	$(obj).siblings().find('.SettingMenuIcon .MenuIconImg').removeClass('enabled');
	$(obj).find('.SettingMenuIcon .MenuIconImg').addClass('enabled');
}

function showSettingMenu()
{
	createSettingMenu();
	changeSettingMenuPosition();
	$('#SettingMenu .SettingMenu_Item').removeClass('Hovered');
	var menu=document.getElementById("SettingMenu");
	menu.style.display = "block";
}

function hideSettingMenu()
{
	createSettingMenu();
	var menu=document.getElementById("SettingMenu");
	menu.style.display="none";
}

function toggleSettingMenu()
{
	if ($('#SettingMenu').length<=0){createSettingMenu();}
	
	var menu=document.getElementById("SettingMenu");
	if (menu.style.display!="block")
	{
		changeSettingMenuPosition();
		updateSettingMenuStatus();
		menu.style.display="block";
	}
	else
	{
		menu.style.display="none";
	}
}

function changeSetting(obj)
{
	window.external.SetMsnTodayStatus(obj.id.substring(16));
	$(obj).siblings().find('.SettingMenuIcon .MenuIconImg').removeClass('enabled');
	$(obj).find('.SettingMenuIcon .MenuIconImg').addClass('enabled');
}

/******************************************************/

function Min_onclick()
{
    window.external.OnMin();
}

function Close_onclick()
{
    window.external.HideWin();
}

function loadOnlineMSNToday()
{
    window.external.SuspendHooks(500);
    setTimeout(function ()
    {
        window.external.ShowWin();

        $('#loading').show();
        $('#timeout').hide();
        $('#main').hide();

        LoadIframe(
        "MsnToday_Online",
        "http://css.cn.msn.com/msntoday/dictoday/default.shtml" + "?timestamp=" + (new Date()).getTime(),
        OnlineMSNTodayLoaded,
        OnlineMSNTodayTimeout
        );
    }, 0);
}

function OnlineMSNTodayLoaded()
{
	window.external.SuspendHooks(500);
	$('#loading').hide();
	$('#timeout').hide();
	$('#main').show();
}

function OnlineMSNTodayTimeout()
{
	window.external.SuspendHooks(500);
    $('#loading').hide();
	$('#timeout').show();
	$('#main').hide();
}



function LoadIframe(ifrmId,url,CallbackOnSucceed,CallbackOnFail)
{
    var xmlhttp;
    try
    {
        if (window.XMLHttpRequest)
        {
            //code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        }
        else if (window.ActiveXObject)
        {
            //code for IE5, IE6
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
    }
    catch (e)
    {
        CallbackOnFail();
        return;
    }

    xmlhttp.open("GET", url, true);
    xmlhttp.onreadystatechange = function ()
    {
        if (xmlhttp.readyState == 4) {
            if (xmlhttp.status == 200) {
                if (CallbackOnSucceed && typeof CallbackOnSucceed == "function") {
                    CallbackOnSucceed();
                }
            }
            else {
                if (CallbackOnFail && typeof CallbackOnFail == "function") {
                    CallbackOnFail();
                }
            }
        }
    }
    xmlhttp.send();
    document.frames[ifrmId].location.href = url;
}




/********skin********/
var CurSkinModel = "DefaultModel";
var CurSkinColor = "Blue.css";
var CurSkinImage = "";
function GetCurrentSkinModel()
{
    return CurSkinModel;
}

function GetCurrentSkinColor()
{
    return CurSkinColor;
}

function GetCurrentSkinImage()
{
    return CurSkinImage;
}

function UpdateSkinForPage(model, color, image)
{
    CurSkinModel = model;
    CurSkinColor = color;
    CurSkinImage = image;
    $("link#_NewSkinModel").attr("href", "").attr("href", "../../../skin/Model/" + model + "/MSNTodayDlg/MSNTodayDlg.css");
    $("link#_NewSkinColor").attr("href", "").attr("href", "../../../skin/Color/" + color + ".css");
    $("link#_NewSkinImage").attr("href", "").attr("href", "../../../skin/Image/" + image + "/BgImg.css");
}
