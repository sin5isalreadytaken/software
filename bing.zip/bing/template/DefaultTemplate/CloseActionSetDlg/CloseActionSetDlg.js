﻿//ban drag of <img> and select of header
$(document).ready(
function () {
    $('img').bind('dragstart', function(){return false;});
    $('#header').bind('selectstart', function(){return false;});
}
);

function header_mouse_down()
{
	window.external.OnHeaderMouseDown();
}
//------------------------------------------------------------------------------
//BtnClose
function BtnClose_onclick()
{
    window.external.HideWin();
}

function confirm_onclick() 
{
    window.external.HideWin();
	if ($('#ask_no_more').attr('checked')=='checked')
	{
		window.external.CloseActionSetFlag('true');
	}
	else
	{
		window.external.CloseActionSetFlag('false');
	}
	
	if ($('#close_to_tray').attr('checked')=='checked')
	{
		window.external.CloseToTray();
	}
    else if ($('#close_program').attr('checked') == 'checked') 
	{
		window.external.CloseProgram();
	}
	
}

function InitStatus()
{
    $('#close_to_tray').attr('checked',true);
    $('#ask_no_more').attr('checked',false);
}

/********skin********/
var CurSkinModel = "DefaultModel";
var CurSkinColor = "Blue.css";
var CurSkinImage = "";
function GetCurrentSkinModel()
{
    return CurSkinModel;
}

function GetCurrentSkinColor()
{
    return CurSkinColor;
}

function GetCurrentSkinImage()
{
    return CurSkinImage;
}

function UpdateSkinForPage(model, color, image)
{
    CurSkinModel = model;
    CurSkinColor = color;
    CurSkinImage = image;
    $("link#_NewSkinModel").attr("href", "").attr("href", "../../../skin/Model/" + model + "/CloseActionSetDlg/CloseActionSetDlg.css");
    $("link#_NewSkinColor").attr("href", "").attr("href", "../../../skin/Color/" + color + ".css");
    $("link#_NewSkinImage").attr("href", "").attr("href", "../../../skin/Image/" + image + "/BgImg.css");
}


