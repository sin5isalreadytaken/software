
/********skin********/
function UpdateSkinForPage(model, color, image)
{
    $("link#_NewSkinModel").attr("href", "").attr("href", "../../../skin/Model/" + model + "/BingDictDlg/HelpPage.css");
    $("link#_NewSkinColor").attr("href", "").attr("href", "../../../skin/Color/" + color + ".css");
}

function gotoPage(path)
{
	$('.help-content').hide();
	
	var pagePath=path.substring(0,path.indexOf('#')<0?path.length:path.indexOf('#'));
	var pathNodes=pagePath.split('-');
	var anchor=path.substring(path.indexOf('#')<0?path.length:path.indexOf('#')+1);

	if(pathNodes.length==1 && pathNodes[0]=='hp')
	{
		$('.help-title').html('<span class="help-title-lnkbtn" onclick="gotoPage(\'hp\');">帮助首页</span>');
		
		$('#hp').show();
		if(anchor == '')
		{
			$('#main .Help').scrollTop(0);
		}
		else
		{
			window.location.hash=anchor;
		}
	}
	else if(pathNodes.length==2 && pathNodes[0]=='hp' && pathNodes[1]=='features')
	{
		$('.help-title').html('<span class="help-title-lnkbtn" onclick="gotoPage(\'hp\');">帮助首页</span> > <span class="help-title-lnkbtn" onclick="gotoPage(\'hp#features\');">功能介绍</span>');
		
		$('#features').show();
		if(anchor == '')
		{
			$('#main .Help').scrollTop(0);
		}
		else
		{
			window.location.hash=anchor;
		}
	}
	else if(pathNodes.length==2 && pathNodes[0]=='hp' && pathNodes[1]=='faq')
	{
		$('.help-title').html('<span class="help-title-lnkbtn" onclick="gotoPage(\'hp\');">帮助首页</span> > <span class="help-title-lnkbtn" onclick="gotoPage(\'hp#faq\');">常见问题</span>');
		
		$('#faq').show();
		if(anchor == '')
		{
			$('#main .Help').scrollTop(0);
		}
		else
		{
			window.location.hash=anchor;
		}
	}
	
}

$(document).ready(
function(e)
{
	// hide .back-top first
	$('.back-top').hide();
	
	// fade in/out .back-top
	$('.Help').bind("scroll",function () 
	{
		var backTopBtnBottom=0;
		backTopBtnBottom+=10;
		$(this).find('.back-top').css('bottom',(backTopBtnBottom)+'px');
		if ($(this).scrollTop() > 10) 
		{
			$(this).find('.back-top').fadeIn(100);
		} 
		else
		{
			$(this).find('.back-top').fadeOut(100);
		}
	});

	// scroll body to 0px on click
	$('.back-top').bind(
	{
		click:function() 
		{
			$(this).parent().animate({scrollTop:0}, 100);
			return false;
		},
		mouseover:function() 
		{
			$(this).removeClass('back-top-hovered').removeClass('back-top-pressed').addClass('back-top-hovered');
		},
		mousedown:function() 
		{
			$(this).removeClass('back-top-hovered').removeClass('back-top-pressed').addClass('back-top-pressed');
		},
		mouseup:function() 
		{
			$(this).removeClass('back-top-hovered').removeClass('back-top-pressed').addClass('back-top-hovered');
		},
		mouseout:function() 
		{
			$(this).removeClass('back-top-hovered').removeClass('back-top-pressed');
		}
	});
});


function BtnBack_onclick()
{
	window.parent.BtnBack_onclick();
}