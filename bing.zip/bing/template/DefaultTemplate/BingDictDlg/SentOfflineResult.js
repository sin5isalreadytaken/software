
function checkInNewWordList()
{

    var obj = document.getElementById("addToNewWordList");
    if (obj == undefined) 
    {
        return;
    }

	var dictBarChildNodes= obj.parentNode.childNodes;//childNodes in dictBar
	var headword="",pron="",def="";

	for (var i=0;i<dictBarChildNodes.length;i++)
	{
		var item=dictBarChildNodes[i];
		if (item.nodeType===1)
		{
			if (item.className.toLowerCase()=="dictbartitle")
			{
			    headword = (item.innerHTML).ToHtmlDecode();
				break;
			}
		}
	}
	
	//the following call will lead to crash when headword containning a single qutation mark :window.external.IsInNewWordList
	if (Number(window.external.IsInNewWordList(headword))==0)
	{
		obj.className="";
		obj.className="addToNewWordList_Pending_N";
		obj.title="添加到生词本";
	}
	else
	{	
		obj.className="";
		obj.className="addToNewWordList_Added_N";
		obj.title="已添加到生词本,点击删除"; 
	}
	
}


function addToNewWordList_onclick(obj)
{
	var dictBarChildNodes= obj.parentNode.childNodes;//childNodes in dictBar
	var headword="",pron="",def="";
	for (var i=0;i<dictBarChildNodes.length;i++)
	{
		var item=dictBarChildNodes[i];
		if (item.nodeType===1)
		{
			if (item.className.toLowerCase()=="dictbartitle")
			{
			    headword = (item.innerHTML).ToHtmlDecode();
			}
			if (item.className.toLowerCase()=="dictbarprons")
			{
				for (var j=0;j<item.childNodes.length;j++)
				{
					var dictBarPron=item.childNodes[j];
			
					if (dictBarPron.nodeType===1 && dictBarPron.className.toLowerCase()=="dictbarpron")
					{
				
						for (var k=0;k<dictBarPron.childNodes.length;k++)
						{
							var dictBarPronValue=dictBarPron.childNodes[k];
							if (dictBarPronValue.className=="dictBarPronValue")
							{
								pron=dictBarPronValue.innerHTML;
								break;
							}
						}
						
					}
				}
			}
		}
	}
	var defGroupChildNodes=obj.parentNode.nextSibling.childNodes;//childNodes in defGroups
	for (var i=0;i<defGroupChildNodes.length;i++)
	{
		var defGroup=defGroupChildNodes[i];
		for (var j=0;j<defGroup.childNodes.length;j++)
		{
			var item3=defGroup.childNodes[j];
			if (item3.nodeType===1)
			{
			    if (item3.className == "defPosArea")
			    {
			        def = def + item3.childNodes[0].innerHTML + " ";
			    }
			    if (item3.className == "defCnt")
			    {
			        def = def + item3.innerHTML.replace(/; /g, "；").replace(/;/g, "；") + "; ";
			    }
			}		
		}		
	}
	
	
	if (obj.title=="添加到生词本")
	{
		
		window.external.AddNewWord(headword,pron,def);

		if (Number(window.external.IsInNewWordList(headword))!=0)
		{
			obj.className="";
			obj.className="addToNewWordList_Added_N";
			obj.title="已添加到生词本,点击删除"; 
		}
	}
	else
	{
		window.external.DeleteNewWord(headword);
	
		if (Number(window.external.IsInNewWordList(headword))==0)
		{
			obj.className="";
			obj.className="addToNewWordList_Pending_N";
			obj.title="添加到生词本";
		}
	}
}

/********skin********/
function UpdateSkinForPage(model, color, image) {
    $("link#_NewSkinModel").attr("href", "").attr("href", "../../../skin/Model/" + model + "/BingDictDlg/OfflineResult.css");
    $("link#_NewSkinColor").attr("href", "").attr("href", "../../../skin/Color/" + color + ".css");
}
