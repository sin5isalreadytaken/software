
//-----------------------------------------------
//ban drag of <img>
$(document).ready(
function()
{
	$('img').bind('dragstart',function(){return false;});
}
);

//to detect whether a function exists
function funExists(funName)
{ 
	try
	{  
		if (typeof eval(funName)=="undefined"){return false;} 
		if (typeof eval(funName)=="function"){return true;}
	}
	catch(e)
	{
		return false;
	} 
} 


//----------------------------------------------------
//header 
function header_mouse_down()
{
	window.external.OnHeaderMouseDown();
}

//------------------------------------------------------------
//BtnMin
function BtnMin_onclick()
{
    window.external.OnMin();
}

//------------------------------------------------------------------------------
//BtnClose
function BtnClose_onclick()
{
    window.external.OnClose();//dont try to close window,only hide it.
}


//获取元素的纵坐标 
function getTop(e)
{ 
	var offset=e.offsetTop; 
	if (e.offsetParent!=null) offset+=getTop(e.offsetParent); 
	return offset; 
} 
//获取元素的横坐标 
function getLeft(e)
{ 
	var offset=e.offsetLeft; 
	if (e.offsetParent!=null) offset+=getLeft(e.offsetParent); 
	return offset; 
} 

//获取所有class==n的元素
function getElementsByClassName(n) { 
var classElements = []      ,     allElements = document.getElementsByTagName('*'); 
for (var i=0; i< allElements.length; i++ ) 
{ 
if (allElements[i].className == n ) { 
classElements[classElements.length] = allElements[i]; //某类集合
} 
} 
return classElements; 
}

//内存回收
window.setInterval(
function gc(){ if (document.all) CollectGarbage(); }, 
60000
); 


/*
* Timer类
* @author: kmlxk@yahoo.com.cn
* @created: 2011-2-12 18:51
* 方法: 
* 构造函数: Timer(间隔, 回调函数)
* 清除: clear()
* 使用示例: var timer = new Timer(200, function(t) {alert('nana'); t.clear();} );    
*/
function Timer(interval,functor) 
{
	this.id = 'timer_'+Math.ceil(Math.random()*900000000+100000000);
	eval(this.id+' = this;');
	this.tid = setInterval(this.id+'.callback()',interval)
	this.functor = functor;
	this.callback = function(){
		this.functor(this);
	}
	this.clear = function(){
		clearInterval(this.tid);
	}
}

function ShareRanking_onclick()
{
	var rankJudge=$('#rank-judgement').html();
	var questionPoolAlias=$('#question-pool-alias',parent.frames['QuestionPage'].document).html();
	var promoteTxt = '嗨~我正在使用 @必应词典 的扩展应用-- #单词挑战#';
	var rankTxt=$('#rank-text').html();
	var questionPool='（'+questionPoolAlias+'）';
	
	var scorePercent=parseInt($('#rank-score-content').html().replace('%',''));
	var picUrl='';
	if (scorePercent>=90)
	{
	    picUrl = encodeURIComponent('http://dict.bing.msn.cn/images/20131227/badge1.png');
	}
	else if (scorePercent>=80)
	{
	    picUrl = encodeURIComponent('http://dict.bing.msn.cn/images/20131227/badge2.png');
	}
	else if (scorePercent>=60)
	{
	    picUrl = encodeURIComponent('http://dict.bing.msn.cn/images/20131227/badge3.png');
	}
	else if (scorePercent>=40)
	{
	    picUrl = encodeURIComponent('http://dict.bing.msn.cn/images/20131227/badge4.png');
	}
	else if (scorePercent>=20)
	{
	    picUrl = encodeURIComponent('http://dict.bing.msn.cn/images/20131227/badge5.png');
	}
	else 
	{
	    picUrl = encodeURIComponent('http://dict.bing.msn.cn/images/20131227/badge6.png');
	}

window.open('http://service.weibo.com/share/share.php?' + 'url=' + encodeURIComponent('http://dict.bing.msn.cn/') + '&pic=' + picUrl + '&appkey=2546683754&ralateUid=3167273451' + '&title=' + encodeURIComponent(rankJudge + ' \n' + promoteTxt + ' \n' + rankTxt + questionPool), '_blank', 'width=640, height=480, top=320, left=180, toolbar=no, menubar=no, scrollbars=no, location=yes, resizable=no, status=no');
	window.external.AddChallengeQuota(1);
}

function AddToNWL_onclick(obj)
{
	var headWord='';
	headWord=$(obj).parent().parent().find('.word-to-add').html();
	if (!headWord||headWord=='')
	{
		headWord=$(obj).parent().parent().find('.question-headword').html();
	}

	var def=$(obj).parent().parent().find('.question-text').html()+':'+$(obj).parent().parent().find('.question-choice-text').html();
	if (obj.title=="加入生词本")
	{
		window.external.AddToNWL(headWord,"",def);
	}
	else
	{
		window.external.DeleteInNWL(headWord);
	}
	
	//update the icon and title of btn
	if (!window.external.IsInNWL(headWord))
	{
		obj.title="加入生词本";
		obj.className = "AddToNWL AddToNWL_Pending normal_ba";
	}
	else
	{
		obj.title="移出生词本";
		obj.className="AddToNWL AddToNWL_Added"; 
	}
	updateNWLStatus();
}

function updateNWLStatus()
{

	$('#lower-panel .list-items').children().each(function(i, item) 
	{
		var headWord='';
		headWord=$(item).find('.word-to-add').html();
		if (!headWord||headWord=='')
		{
			headWord=$(item).find('.question-headword').html();
		}
		
        if (window.external.IsInNWL( headWord ))
		{
			$(item).find('.AddToNWL').attr('title','移出生词本');
			$(item).find('.AddToNWL').attr('class','AddToNWL AddToNWL_Added');
		}
		else
		{
			$(item).find('.AddToNWL').attr('title','加入生词本');
			$(item).find('.AddToNWL').attr('class','AddToNWL AddToNWL_Pending normal_ba');
		}
    });
}

function OpenNWL_onclick()
{
    window.external.OpenPlugin('NewWordList','-toDefault');
}

function CheckAnswer_onclick()
{
    parent.showReviewQuestions();
}

function RedoChallenge_onclick() 
{
	$('#ShareRanking',parent.frames['ResultPage'].document).hide();
    getCurrentQuestions();
}

function getCurrentQuestions() 
{
    window.external.getCurrentQuestions();
}

function ContinueChallenge_onclick() 
{
	$('#ShareRanking',parent.frames['ResultPage'].document).show();
    parent.showIframe('QuestionPoolsPage');
    parent.frames['QuestionPoolsPage'].window.location.reload();
}

function setRankScore(rankScore)
{
	$('#rank-score-content').html(rankScore+'%');
}

function setRankJudgement(rankJudge)
{
	$('#rank-judgement').html(rankJudge);
}

function setRankText(rankText)
{
	$('#rank-text').html(rankText);
}

function setHardQuestions(hardQuestions)
{
	$('#lower-panel .list-items').html('').html(hardQuestions).scrollTop(0);
	
	updateNWLStatus();
}


function HeadWord_onclick(obj)
{
    window.external.SearchDict($(obj).html());
    window.external.AddToLog('WC_SearchHeadWord');
}
/********skin********/
function UpdateSkinForPage(model, color, image)
{
    $("link#_NewSkinColor").attr("href", "").attr("href", "../../../../../skin/Color/" + color + ".css");
}

