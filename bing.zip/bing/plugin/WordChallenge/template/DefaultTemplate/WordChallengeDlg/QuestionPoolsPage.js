
//-----------------------------------------------
//ban drag of <img>
$(document).ready(
function()
{
	$('img').bind('dragstart',function(){return false;});
}
);

//to detect whether a function exists
function funExists(funName)
{ 
	try
	{  
		if (typeof eval(funName)=="undefined"){return false;} 
		if (typeof eval(funName)=="function"){return true;}
	}
	catch(e)
	{
		return false;
	} 
} 

//detect and response to keyboard event
$(document).ready(
function () {
$(document).bind('keydown',window.event,keyDown)
.bind('keyup',window.event,keyUp)
.bind('keypress',window.event,keyPress)
;
$(window.parent.document).bind('keydown',window.parent.event,keyDown)
.bind('keyup',window.parent.event,keyUp)
.bind('keypress',window.parent.event,keyPress)
;
}
);
function keyDown(evt)
{
	return false;
}
function keyUp(evt)
{
	//only should be triggered when current page is QuestionPage
	if (window.parent.window.currentIframe!='QuestionPoolsPage')
	{
		return;
	}
	
	var keyCode = evt.keyCode;

	if (keyCode == 37 || keyCode == 39 || keyCode == 38 || keyCode == 40)//left,right,up,down
	{
		trySelectQuestionPool(keyCode);
		return;
	}
}
function keyPress(evt)
{
}


function trySelectQuestionPool(keyCode)
{
	var $Items=$('#question-pool-list-items .list-item');
	var $hoveredItem=$Items.siblings('.hovered');
	var $theItem;
	
	if ($hoveredItem.length==0)
	{
		if (keyCode==37 || keyCode==38)
		{
			$theItem=$Items.last();
		}
		else if (keyCode==39 || keyCode==40)
		{
			$theItem=$Items.first();
		}	
	}
	
	else if ($hoveredItem.length>=1)
	{
		if (keyCode==37 || keyCode==38)
		{
			$theItem=$hoveredItem.prev();
			if ($theItem.length==0)
			{
				$theItem=$Items.last();
			}
		}
		else if (keyCode==39 || keyCode==40)
		{
			$theItem=$hoveredItem.next();
			if ($theItem.length==0)
			{
				$theItem=$Items.first();
			}
		}	
	}

	$Items.siblings('.hovered').removeClass('hovered');
	$theItem.addClass('hovered');
	
	//auto scroll
	if ($theItem.position().top < 0)
	{
		$theItem.parent().scrollTop($theItem.parent().scrollTop() + $theItem.offset().top - 40);
	}
	if ($theItem.position().top + $theItem.outerHeight() > $theItem.parent().height())
	{
		$theItem.parent().scrollTop($theItem.parent().scrollTop() + $theItem.position().top + $theItem.outerHeight() + parseInt($theItem.css('margin-top')) - $theItem.parent().height());
	}

}


//----------------------------------------------------
//header 
function header_mouse_down()
{
	window.external.OnHeaderMouseDown();
}

//------------------------------------------------------------
//BtnMin
function BtnMin_onclick()
{
    window.external.OnMin();
}

//------------------------------------------------------------------------------
//BtnClose
function BtnClose_onclick()
{
    window.external.OnClose();//dont try to close window,only hide it.
}



//获取元素的纵坐标 
function getTop(e)
{ 
	var offset=e.offsetTop; 
	if (e.offsetParent!=null) offset+=getTop(e.offsetParent); 
	return offset; 
} 
//获取元素的横坐标 
function getLeft(e)
{ 
	var offset=e.offsetLeft; 
	if (e.offsetParent!=null) offset+=getLeft(e.offsetParent); 
	return offset; 
} 

//获取所有class==n的元素
function getElementsByClassName(n) { 
var classElements = []      ,     allElements = document.getElementsByTagName('*'); 
for (var i=0; i< allElements.length; i++ ) 
{ 
if (allElements[i].className == n ) { 
classElements[classElements.length] = allElements[i]; //某类集合
} 
} 
return classElements; 
}

//内存回收
window.setInterval(
function gc(){ if (document.all) CollectGarbage(); }, 
60000
); 


/*
* Timer类
* @author: kmlxk@yahoo.com.cn
* @created: 2011-2-12 18:51
* 方法: 
* 构造函数: Timer(间隔, 回调函数)
* 清除: clear()
* 使用示例: var timer = new Timer(200, function(t) {alert('nana'); t.clear();} );    
*/
function Timer(interval,functor) 
{
	this.id = 'timer_'+Math.ceil(Math.random()*900000000+100000000);
	eval(this.id+' = this;');
	this.tid = setInterval(this.id+'.callback()',interval)
	this.functor = functor;
	this.callback = function(){
		this.functor(this);
	}
	this.clear = function(){
		clearInterval(this.tid);
	}
}


function getBestResult()
{
	window.external.GetBestResult();
}

function setBestResult(bestRestult)
{
	$("#best-result-content").html('').html(bestRestult);
}

function getRecentResult()
{
	window.external.GetRecentResult();
}

function setRecentResult(recentRestult)
{
    $("#recent-result-content").html(recentRestult);
}

function getQuestionPoolList()
{
	$("#question-pool-list-items").html('').html("<div id=\"loading\"><div id=\"loading-txt\">正在加载试题列表，请稍候。</div><div id=\"loading-img\"></div></div>");
	window.external.GetQuestionPoolList();
}
function setQuestionPoolList(questionPoolList)
{
	$("#question-pool-list-items").html('').html(questionPoolList);
}

function RefreshQuestionPoolList_onclick()
{
	getQuestionPoolList();
}

function QuestionPool_onclick(obj)
{
    window.external.getNewQuestions($(obj).find('.list-item-name').html(), $(obj).find('.list-item-type').html(), $(obj).find('.list-item-alias').html());
    window.external.AddToLog('WC_QuestionPoolOnClick:' + $(obj).find('.list-item-name').html());
}

//---------------------------------------------------------//

var bInShareMenuArea = false;
function Share_onblur()
{
	if (bInShareMenuArea) 
	{ 
		$('#Share').focus();
		return false;
	}
    else 
	{ 
        hideShareMenu();
    }
}

function Share_onclick()
{
	toggleShareMenu();
}

function createShareMenu()
{
	var ItemString = '\
	<div id="ShareMenu"  onmouseenter="bInShareMenuArea=true;" onmouseleave="bInShareMenuArea=false;">\
		<div class="ShareMenu_Item" id="ShareMenu_Item1"\
		onmousedown="hideShareMenu();ShareToWeibo();" \
		onmouseover="$(this).siblings().removeClass(\'Hovered\');$(this).addClass(\'Hovered\');"\
		onmouseout="$(this).removeClass(\'Hovered\');"\
		>\
			<div class="ShareMenuIcon"></div>\
			<div class="ShareMenuTxt">新浪微博</div>\
		</div>\
		<div class="ShareMenu_Segment">\
        	<div class="ShareMenuTxt"></div>\
        </div>\
		<div class="ShareMenu_Item" id="ShareMenu_Item2"\
		onmousedown="hideShareMenu();ShareToRenren();"\
		onmouseover="$(this).siblings().removeClass(\'Hovered\');$(this).addClass(\'Hovered\');"\
		onmouseout="$(this).removeClass(\'Hovered\');"\
		>\
			<div class="ShareMenuIcon"></div>\
			<div class="ShareMenuTxt">人人网</div>\
		</div>\
		<div class="ShareMenu_Segment">\
        	<div class="ShareMenuTxt"></div>\
        </div>\
		<div class="ShareMenu_Item" id="ShareMenu_Item3"\
		onmousedown="hideShareMenu();ShareToQZone();"\
		onmouseover="$(this).siblings().removeClass(\'Hovered\');$(this).addClass(\'Hovered\');"\
		onmouseout="$(this).removeClass(\'Hovered\');"\
		>\
			<div class="ShareMenuIcon"></div>\
			<div class="ShareMenuTxt">QQ空间</div>\
		</div>\
		<div class="ShareMenu_Segment">\
        	<div class="ShareMenuTxt"></div>\
        </div>\
		<div class="ShareMenu_Item" id="ShareMenu_Item4"\
		onmousedown="hideShareMenu();ShareToTencentT();"\
		onmouseover="$(this).siblings().removeClass(\'Hovered\');$(this).addClass(\'Hovered\');"\
		onmouseout="$(this).removeClass(\'Hovered\');"\
		>\
			<div class="ShareMenuIcon"></div>\
			<div class="ShareMenuTxt">腾讯微博</div>\
		</div>\
	</div>\
    ';
    	
	var menu=document.getElementById("ShareMenu");
	if (menu==undefined || menu==null)
	{
		var a=document.createElement("div");
		a.innerHTML=ItemString;
		document.body.appendChild(a);
	}
	menu=document.getElementById("ShareMenu");
	menu.style.display="none";
	return;
}

function changeShareMenuPosition()
{
	var BtnShare=document.getElementById("Share");
	var x=getLeft(BtnShare);
	var y=getTop(BtnShare);
	var x2=x;
	var y2=y-101;

	var menu=document.getElementById("ShareMenu");
	menu.style.top=y2+'px';
	menu.style.left=x2+'px';

	return;
}

function showShareMenu()
{
	createShareMenu();
	changeShareMenuPosition();
	$('#ShareMenu .ShareMenu_Item').removeClass('Hovered');
	var menu=document.getElementById("ShareMenu");
	menu.style.display = "block";
}

function hideShareMenu()
{
	createShareMenu();
	var menu=document.getElementById("ShareMenu");
	menu.style.display="none";
}

function toggleShareMenu()
{
	if ($('#ShareMenu').length<=0){createShareMenu();}
	
	var menu=document.getElementById("ShareMenu");
	if (menu.style.display!="block")
	{
		changeShareMenuPosition();
		menu.style.display="block";
	}
	else
	{
		menu.style.display="none";
	}
}


function ShareToWeibo()
{
	var txt = '嗨~我正在使用 @必应词典 的扩展应用 #单词挑战# ！~ 覆盖各种英语等级和应用场景，迅速提升您的词汇量！ 想要和我一起挑战单词吗？ 马上猛戳这里下载 @必应词典 吧~';
	window.open('http://service.weibo.com/share/share.php?' + 'url=' + encodeURIComponent('http://bing.msn.cn/dict/') + '&appkey=2546683754&ralateUid=3167273451' + '&title=' + encodeURIComponent(txt),
	'_blank','width=640, height=480, top=320, left=180, toolbar=no, menubar=no, scrollbars=no, location=yes, resizable=no, status=no'
	);
	window.external.AddChallengeQuota(1);
	window.external.AddToLog('WC_ShareToWeibo');
}

function ShareToRenren()
{
	var txt = '嗨~我正在使用 @必应词典 的扩展应用 #单词挑战# ！~ 覆盖各种英语等级和应用场景，迅速提升您的词汇量！ 想要和我一起挑战单词吗？ 马上猛戳这里下载 @必应词典 吧~';
	window.open('http://widget.renren.com/dialog/share?resourceUrl='+ encodeURIComponent('http://bing.msn.cn/dict/') +'&form=BDVB05&title=%e5%bf%85%e5%ba%94%e8%af%8d%e5%85%b8&description='+encodeURIComponent(txt),
	'_blank','width=640, height=500, top=320, left=180, toolbar=no, menubar=no, scrollbars=no, location=yes, resizable=no, status=no'
	);
	window.external.AddChallengeQuota(1);
	window.external.AddToLog('WC_ShareToRenren');
}

function ShareToQZone()
{
	var txt = '嗨~我正在使用 @必应词典 的扩展应用 #单词挑战# ！~ 覆盖各种英语等级和应用场景，迅速提升您的词汇量！ 想要和我一起挑战单词吗？ 马上猛戳这里下载 @必应词典 吧~';
	window.open('http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url='+ encodeURIComponent('http://bing.msn.cn/dict/') +'&form=BDVB05&title=%e5%bf%85%e5%ba%94%e8%af%8d%e5%85%b8&summary=' + encodeURIComponent(txt),
	'_blank','width=640, height=480, top=320, left=180, toolbar=no, menubar=no, scrollbars=no, location=yes, resizable=no, status=no'
	);
	window.external.AddChallengeQuota(1);
	window.external.AddToLog('WC_ShareToQZone');
}

function ShareToTencentT()
{
	var txt = '嗨~我正在使用 @必应词典 的扩展应用 #单词挑战# ！~ 覆盖各种英语等级和应用场景，迅速提升您的词汇量！ 想要和我一起挑战单词吗？ 马上猛戳这里下载 @必应词典 吧~';
	window.open('http://share.v.t.qq.com/index.php?c=share&a=index&url='+ encodeURIComponent('http://bing.msn.cn/dict/') +'&form=BDVB05&title='+ encodeURIComponent(txt),
	'_blank','width=640, height=480, top=320, left=180, toolbar=no, menubar=no, scrollbars=no, location=yes, resizable=no, status=no'
	);
	window.external.AddChallengeQuota(1);
	window.external.AddToLog('WC_ShareToTencentT');
}


//---------------------------------------------------------//

var bInSuggestMenuArea = false;
function Suggest_onblur()
{
	if (bInSuggestMenuArea) 
	{ 
		$('#Suggest').focus();
		return false;
	}
    else 
	{ 
        hideSuggestMenu();
    }
}

function Suggest_onclick()
{
	toggleSuggestMenu();
}

function createSuggestMenu()
{
	var ItemString = '\
	<div id="SuggestMenu"  onmouseenter="bInSuggestMenuArea=true;" onmouseleave="bInSuggestMenuArea=false;">\
		<div class="SuggestMenu_Item" id="SuggestMenu_Item1"\
		onmousedown="hideSuggestMenu();SendEmailSuggest_onclick();" \
		onmouseover="$(this).siblings().removeClass(\'Hovered\');$(this).addClass(\'Hovered\');"\
		onmouseout="$(this).removeClass(\'Hovered\');"\
		>\
			<div class="SuggestMenuTxt">发邮件</div>\
		</div>\
		<div class="SuggestMenu_Segment">\
        	<div class="SuggestMenuTxt"></div>\
        </div>\
		<div class="SuggestMenu_Item" id="SuggestMenu_Item2"\
		onmousedown="hideSuggestMenu();SendWeiboSuggest_onclick();"\
		onmouseover="$(this).siblings().removeClass(\'Hovered\');$(this).addClass(\'Hovered\');"\
		onmouseout="$(this).removeClass(\'Hovered\');"\
		>\
			<div class="SuggestMenuTxt">发微博</div>\
		</div>\
	</div>\
    ';
    	
	var menu=document.getElementById("SuggestMenu");
	if (menu==undefined || menu==null)
	{
		var a=document.createElement("div");
		a.innerHTML=ItemString;
		document.body.appendChild(a);
	}
	menu=document.getElementById("SuggestMenu");
	menu.style.display="none";
	return;
}

function changeSuggestMenuPosition()
{
	var BtnSuggest=document.getElementById("Suggest");
	var x=getLeft(BtnSuggest);
	var y=getTop(BtnSuggest);
	var x2=x;
	var y2=y-51;

	var menu=document.getElementById("SuggestMenu");
	menu.style.top=y2+'px';
	menu.style.left=x2+'px';

	return;
}

function showSuggestMenu()
{
	createSuggestMenu();
	changeSuggestMenuPosition();
	$('#SuggestMenu .SuggestMenu_Item').removeClass('Hovered');
	var menu=document.getElementById("SuggestMenu");
	menu.style.display = "block";
}

function hideSuggestMenu()
{
	createSuggestMenu();
	var menu=document.getElementById("SuggestMenu");
	menu.style.display="none";
}

function toggleSuggestMenu()
{
	if ($('#SuggestMenu').length<=0){createSuggestMenu();}
	
	var menu=document.getElementById("SuggestMenu");
	if (menu.style.display!="block")
	{
		changeSuggestMenuPosition();
		menu.style.display="block";
	}
	else
	{
		menu.style.display="none";
	}
}

function SendEmailSuggest_onclick()
{
	window.open('mailto:bingdictQA@microsoft.com?subject=关于必应词典的单词挑战应用的反馈&body=必应词典开发者：%0a关于必应词典的单词挑战应用我有一些意见和建议：');

	window.external.AddToLog('WC_SendEmailSuggest');
}


function SendWeiboSuggest_onclick()
{
	var txt = '@必应词典 #单词挑战# 我想对你说：';
	window.open('http://service.weibo.com/share/share.php?' + 'url=' + encodeURIComponent('http://dict.bing.msn.cn/') + '&appkey=2546683754&ralateUid=3167273451' + '&title=' + encodeURIComponent(txt),
	'_blank','width=640, height=480, top=320, left=180, toolbar=no, menubar=no, scrollbars=no, location=yes, resizable=no, status=no'
	);

	window.external.AddToLog('WC_SendWeiboSuggest');
}


/************************************************************/
function showPopupMsgBox()
{
	$('#main .PopupMsgBox').show();
}

function hidePopupMsgBox()
{
	$('#main .PopupMsgBox').hide();
}

function emptyRecord()
{
	window.external.EmptyRecord();
}
/************************************************************/

function NoRemainQuota()
{
	$('#warning1').css({'opacity':0,'display':'block'})
		.animate({'opacity':1},500)
		.delay(1000).animate({'opacity':0},500,function(){ $('#warning').css('display','none');} );
}

function FailGetRankData()
{
    $('#warning2').css({ 'opacity': 0, 'display': 'block' })
    .animate({ 'opacity': 1 }, 500)
    .delay(1000).animate({ 'opacity': 0 }, 500, function () { $('#warning').css('display', 'none'); });
}

function FailGetNewQuestions()
{
	$('#warning2').css({'opacity':0,'display':'block'})
		.animate({'opacity':1},500)
		.delay(1000).animate({'opacity':0},500,function(){ $('#warning').css('display','none');} );
}

function Detail_onclick()
{
	window.open('http://bing.msn.cn/dict/wordgame');
}

function toggle_arrow_onclick()
{
	if ($('#toggle_panel #toggle_arrow').hasClass('Toggle_Arrow_Left') == true)
	{
		$('#toggle_panel #toggle_arrow').attr({'class':'Toggle_Arrow_Right','title':'收起题库'});
		$('#toggle_panel').css({'left':'0px','right':'auto'});

		$('#left-panel').css({'width':'0px','overflow':'hidden'});
		$('#right-panel').css({'left':'7px','right':'0px','width':'auto','border-left':'none'}).addClass('full-panel-mode');
	}
	else 
	{
		$('#toggle_panel #toggle_arrow').attr({'class':'Toggle_Arrow_Left','title':'展开题库'});
		$('#toggle_panel').css({'right':'180px','left':'auto'});
		
		$('#left-panel').css({'width':'auto'});
		$('#right-panel').css({'left':'auto','right':'0px','width':'180px','border-left':'none'}).removeClass('full-panel-mode');
	}
 }
/********skin********/
function UpdateSkinForPage(model, color, image)
{
    $("link#_NewSkinColor").attr("href", "").attr("href", "../../../../../skin/Color/" + color + ".css");
}
