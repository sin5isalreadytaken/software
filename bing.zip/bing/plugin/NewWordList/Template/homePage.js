﻿
$(document).bind("contextmenu", function () { return false; });
$(document).keydown(function () 
{
    if (event.keyCode == 116) 
	{
        event.keyCode = 0;
        event.returnValue = false;
        return false;
    }

    if (window.event.ctrlKey) 
	{
        isCtrl = true;
    }
    if (window.event.shiftKey) 
	{
        isShift = true;
    }
});
$(document).keyup(function () 
{
    isCtrl = false;
    isShift = false;
});

function amouseover(obj) 
{
    $(obj).addClass("amouseover");
    if (obj.style.backgroundColor != "#e2e2e2")
    {
        obj.style.backgroundColor = "#f7ecea";
    }
}

function amouseout(obj) 
{
    $(obj).removeClass("amouseover");
    if (obj.style.backgroundColor != "#e2e2e2")
    {
        obj.style.backgroundColor = "white";
    }
}


$(function () 
{
    $('.syncBTNDefault').parent().find('em').hide();

    $('.syncBTN').bind('click', function (e) 
	{
        new Image().src = 'http://t.msn.com.cn/activity/l.gif?nocache=' + new Date().getTime() +'&pt=' + manto.cookieTool('manto_user_ct') + '&d=client.dict.bing.msn.cn&v=1&c=http://client.dict.bing.msn.cn%60%60click%60BingDict_v2.0_syncBtn';
        window.external.Sync();
        return false;
    });
    $('.addBTN').bind('click', function () 
	{
        window.external.AddNotebook();
        return false;
    });
    $('.deleteBTN').bind('click', function () 
	{
        window.external.DeleteNotebooks();
        return false;
    });
    $('.editBTN').bind('click', function () 
	{
        window.external.RenameNotebook();
    });
});

//----------------------------------------------------//
//1.默认状态的同步按钮
//1.1
//前端方法:点击同步按钮后发现还没有登录,则显示"默认"的同步按钮,并显示"正在登录"的状态文字
function loginFront()
{
    var $syncBtn = $('.actBTN .syncBTNWrap'),
        $el = $('.syncBTNDefault').parent();
    $el.find('em').hide();
    $('em.syncLogin', $el).show();
}
//1.2
//前端方法,同步完成以后,先显示"同步完成"的同步按钮,然后切换到"默认"的同步按钮,并定期刷新"距上次同步时间"
var timer = null;
function endSyncFront(day)
{
    var $wrap = $('.actBTN'),
        $syncBtn = $('.actBTN .syncBTNWrap'),
        $el = $('.syncBTNDefault', $wrap).parent(),
        day = new Date(day);
    $syncBtn.removeClass('dI');
    $('.syncBTNEnd', $wrap).parent().addClass('dI');

    //定期显示"距上次同步时间"
    setTimeout(function ()
    {
        $syncBtn.removeClass('dI');
        $el.addClass('dI');
        $el.find('em').hide();
        $('em.default', $el).text(checkTime(day)).show();
        clearInterval(timer);
        timer = null;
        timer = setInterval(function ()
        {
            $('em.defualt', $el).text(checkTime(day));
        }, 1000 * 60);
    }, 2000);
}
//1.3 
//前端方法,如果用户没有登录,则仅显示"默认"的同步按钮; 如果用户刚登录还没有开始同步,则显示"默认"的同步按钮,并定期刷新"距上次同步时间"; 如果用户同步失败,则仅显示"默认"的同步按钮
function statusFront(className, day)
{
    var $syncBtn = $('.actBTN .syncBTNWrap'),
		$el = $('.syncBTNDefault').parent(),
		$currentEl = $('em.' + className, $el);
    $syncBtn.removeClass('dI');
    $el.addClass('dI');
    $el.find('em').hide();
    $currentEl.show();

    //定期显示"距上次同步时间"
    if (className === 'default' && day !== undefined)
    {
        $currentEl.text(checkTime(day)).show();
        clearInterval(timer);
        timer = null;
        timer = setInterval(function ()
        {
            $currentEl.text(checkTime(day));
        }, 1000 * 60);
    }
}


//2.有新内容需要同步状态的同步按钮
//2.1
//前端方法,当用户已经登录,并进行了一些操作导致有新的可以同步的内容时,显示"有新内容需要同步"的同步按钮
function hasNewWordFront()
{
    var $wrap = $('.actBTN'),
        $syncBtn = $('.actBTN .syncBTNWrap');
    $syncBtn.removeClass('dI');
    $('.syncBTNNew', $wrap).parent().addClass('dI');
}


//3.同步中的同步按钮
//3.1
//前端方法,当正式开始同步的时候,显示"正在和云端同步"状态
function setSyncBTNIngVisible()
{
    $loadingWrap = $('.actBTN .syncBTNIng').parent();
    if ($loadingWrap.hasClass('dI'))
    {
        return;
    }

    $('.actBTN .syncBTNWrap').removeClass('dI');//先隐藏所有的sync button wrappers
    $loadingWrap.addClass('dI');//再显示syncing button wrapper

    $('>em', $loadingWrap).hide();//先隐藏所有syncing button wrapper下面的所有文字
    $loadingWrap.find('.syncProcess').show();//再显示syncing button wrapper下面文字"正在和云端同步"
}
//3.2
//前端方法,让前端切换到"正在和云端同步"状态
function startSyncFront()
{
    var $wrap = $('.actBTN'),//action buttons
        $syncBtn = $('.actBTN .syncBTNWrap'),//sync button wrappers
        $el,//currently displayed syncBTN
        $loadingWrap = $('.syncBTNIng', $wrap).parent();//syncing button wrapper

    //find currently displaying syncBTN
    $('.syncBTNWrap').each(function ()
    {
        if ($(this).hasClass('dI'))
        {
            $el = $('.syncBTN', this);
        }
    });

    //切换到"正在和云端同步"状态
    if ($el.hasClass('syncBTNDefault') || $el.hasClass('syncBTNEnd') || $el.hasClass('syncBTNNew')) //如果当前正在展示的是以下状态:默认状态,同步完成,有新内容需要同步.
    {
        $syncBtn.removeClass('dI');//先隐藏所有的sync button wrappers
        $loadingWrap.addClass('dI');//再显示syncing button wrapper

        $('>em', $loadingWrap).hide();//先隐藏所有syncing button wrapper下面的所有文字
        $loadingWrap.find('.syncProcess').show();//再显示syncing button wrapper下面文字"正在和云端同步"
    }
};
//3.3
//前端方法,在同步过程中,用于改变同步中的状态文字
function checkTextFront(statusCode)
{
    var $wrap = $('.syncBTNIng').parent(), $em = $('>em', $wrap);
    $em.hide();
    switch (statusCode)
    {
        case 'upload':
            $wrap.find('.syncUpload').show(); break;
        case 'download':
            $wrap.find('.syncDownload').show(); break;
        case 'merge':
            $wrap.find('.syncMerge').show(); break;
        case 'login':
            $wrap.find('.syncSignin').show(); break;
        default:;
    }
}


//前端方法,用于生成"距上次同步时间"的状态文字
function checkTime(time)
{
    var date = new Date(time);
    var now = new Date();
    var date_year = date.getFullYear();
    var date_month = date.getMonth() + 1;
    var date_day = date.getDate();
    var date_hour = date.getHours();
    var now_year = now.getFullYear();
    var now_month = now.getMonth() + 1;
    var now_day = now.getDate();
    var now_hour = now.getHours();
    if (now_year > date_year || now_month > date_month || now_day > date_day)
    {
        date = '上次同步:' + date.getFullYear() + '/' + date_month + '/' + date_day;
        if (date_year < 2001)
        {
            date = '您还未同步过';
        }
    }
    else
    {
        if ((now_hour - date_hour) > 0)
        {
            if (now_hour - date_hour === 1 && now.getMinutes() < date.getMinutes())
            {
                date = '上次同步:' + (now.getMinutes() - date.getMinutes() + 60) + '分钟前';
            }
            else
            {
                date = '上次同步:' + (now_hour - date_hour) + '小时前';
            }
        }
        else
        {
            var minutes = now.getMinutes() - date.getMinutes();
            if (minutes < 2)
            {
                date = '上次同步：刚刚';
            }
            else
            {
                date = '上次同步:' + (now.getMinutes() - date.getMinutes()) + '分钟前';
            }
        };
    };
    return date;
}

//----------------------------------------------------//
var isCtrl = false;
var isShift = false;
var ls = -1;
function MOutBgColor(obj)
{
    if (obj.style.backgroundColor != "#e2e2e2")
    {
        obj.style.backgroundColor = "white";
    }
}
function MOverBgColor(obj)
{
    if (obj.style.backgroundColor != "#e2e2e2")
    {
        obj.style.backgroundColor = "#f7ecea";
    }
}
function Open(obj)
{
    ItemSingleSelect(obj);
    window.external.GotoSelectedBookunit();
}
function MDown(obj)
{
    //trace right button of mouse
    if (event.button == 2)
    {
        ItemSingleSelect(obj);
        window.external.ShowNotebookContextMenu(event.clientX, event.clientY);

    }
}
function ItemSingleSelect(obj)
{
    $("td div").each(function ()
    {
        if ($(this).attr("id") != obj.id)
        {
            $(this).css("backgroundColor", "white");
        }
    });
    var bgColor = obj.style.backgroundColor;
    //unselected
    if (bgColor != "#e2e2e2")
    {
        obj.style.backgroundColor = "#e2e2e2";
    }
    window.external.GetNotebookSingleSelected(obj.id);
}
function ItemSelect(obj)
{
    var i = 0;

    if (!isShift)
    {
        ls = $(obj).find("input").eq(0).val();
    }

    if (!isShift)
    {
        if (!isCtrl)
        {
            $("td div").each(function ()
            {
                if ($(this).css("backgroundColor") == "#e2e2e2")
                {
                    i++;
                }
                if ($(this).attr("id") != obj.id)
                {
                    $(this).css("backgroundColor", "white");
                }
            });
        }
        var bgColor = obj.style.backgroundColor;
        //unselected
        if (bgColor == "#e2e2e2")
        {
            if (i <= 1)
            {
                obj.style.backgroundColor = "#f7ecea";
            }
        }
        else
        {
            obj.style.backgroundColor = "#e2e2e2";
        }

        window.external.GetNotebookSelected(obj.id, isCtrl);
    }
    else
    {
        if (ls == -1)
        {
            ls = $(obj).find("input").eq(0).val();
            var bgColor = obj.style.backgroundColor;
            obj.style.backgroundColor = "#e2e2e2";
            window.external.GetNotebookSelected(obj.id, isCtrl);

        }
        else
        {
            var tm = $(obj).find("input").eq(0).val();
            var ils = parseInt(ls);
            var itm = parseInt(tm);
            if (ils > itm)
            {
                ils = ils + itm;
                itm = ils - itm;
                ils = ils - itm;
            }
            var ids = "";

            $("td div").each(function ()
            {
                var t = $(this).find("input").eq(0).val();
                var it = parseInt(t);
                if (ils <= it && it <= itm)
                {
                    $(this).css("backgroundColor", "#e2e2e2");
                    ids = ids + $(this).attr("id") + ",";
                }
                else
                {
                    $(this).css("backgroundColor", "white");
                }
            });

            window.external.GetNotebookSuccessiveSlt(ids);
        }
    }
    i = 0;
}
function initializelLs()
{
    ls = -1;
}
function ClearSelected()
{
    $("td div").each(function ()
    {
        $(this).css("backgroundColor", "white")
    });
}

function fixPNG(myImage)
{
    var arVersion = navigator.appVersion.split("MSIE");
    var version = parseFloat(arVersion[1]);
    if ((version >= 5.5) && (version < 7) && (document.body.filters))
    {
        var imgID = (myImage.id) ? "id='" + myImage.id + "' " : "";
        var imgClass = (myImage.className) ? "class='" + myImage.className + "' " : "";
        var imgTitle = (myImage.title) ? "title='" + myImage.title + "' " : "title='" + myImage.alt + "' ";
        var imgStyle = "display:inline-block;" + myImage.style.cssText;
        var strNewHTML = "<span " + imgID + imgClass + imgTitle
			+ " style=\"" + "width:" + myImage.width
			+ "px; height:" + myImage.height
			+ "px;" + imgStyle + ";"
			+ "filter:progid:DXImageTransform.Microsoft.AlphaImageLoader"
			+ "(src=\'" + myImage.src + "\', sizingMethod='scale');\"></span>";
        myImage.outerHTML = strNewHTML;
    }
}
